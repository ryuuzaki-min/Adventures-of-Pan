package id.pulautebak.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.window.OnBackInvokedDispatcher;
import android.widget.FrameLayout;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/**
 * Petualangan Panpan dan Akapan: game dimuat dari folder assets/www di dalam aplikasi lewat
 * WebViewAssetLoader, jadi bisa dimainkan tanpa internet.
 * Varian github memeriksa pembaruan di GitHub Releases (BuildConfig.SELF_UPDATE = true).
 * Varian play tidak memakai internet sama sekali; pembaruan lewat Google Play.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/www/index.html";

    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean checking = false;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        web.setBackgroundColor(0xFFFFF6DF);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFFFFF6DF);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Layar penuh (wajib sejak Android 15/16): isi digeser menjauh dari status bar, navigasi, dan poni kamera.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat ic = WindowCompat.getInsetsController(getWindow(), root);
        ic.setAppearanceLightStatusBars(true);
        ic.setAppearanceLightNavigationBars(true);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets b = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        // Tombol kembali: Android 13+ memakai OnBackInvokedCallback (Android 16 tidak lagi memanggil onBackPressed).
        if (Build.VERSION.SDK_INT >= 33) Api33.daftarKembali(this, this::kembali);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Jembatan(), "PTAndroid");

        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            int r = tts.setLanguage(new Locale("id", "ID"));
            ttsReady = r >= TextToSpeech.LANG_AVAILABLE;
            tts.setSpeechRate(0.95f);
            tts.setPitch(1.15f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String id) {
                }

                @Override
                public void onDone(String id) {
                    selesai(id);
                }

                @Override
                public void onError(String id) {
                    selesai(id);
                }

                @Override
                public void onStop(String id, boolean interrupted) {
                    selesai(id);
                }
            });
        });

        if (saved != null) web.restoreState(saved);
        else web.loadUrl(START);

        if (BuildConfig.SELF_UPDATE) ui.postDelayed(() -> cekPembaruan(false), 4000);
    }

    private void selesai(String id) {
        ui.post(() -> {
            if (web != null)
                web.evaluateJavascript("window.__ttsDone&&window.__ttsDone(" + JSONObject.quote(id) + ")", null);
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        web.evaluateJavascript("window.ptPause&&window.ptPause()", null);
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        web.evaluateJavascript("window.ptResume&&window.ptResume()", null);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /** Android 12 ke bawah. */
    @Override
    @SuppressWarnings({"deprecation", "MissingSuperCall"})
    public void onBackPressed() {
        kembali();
    }

    /** Dipisah supaya kelas Android 13 tidak dimuat di HP lama. */
    private static final class Api33 {
        static void daftarKembali(Activity a, Runnable r) {
            a.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, r::run);
        }
    }

    /** Tutup jendela, atau tekan tombol kembali di game; di beranda, aplikasi diminimalkan. */
    private void kembali() {
        if (web == null) return;
        String js = "(function(){try{var m=document.querySelector('#modal');"
                + "if(m&&!m.hidden){if(!m.dataset.lock)closeModal();return 'ok'}"
                + "var b=document.querySelector('[data-a=\"back\"]');if(b){b.click();return 'ok'}}catch(e){}return 'home'})()";
        web.evaluateJavascript(js, v -> {
            if ("\"home\"".equals(v)) moveTaskToBack(true);
        });
    }

    /** Fungsi yang bisa dipanggil game lewat window.PTAndroid. */
    private class Jembatan {
        @JavascriptInterface
        public boolean ttsReady() {
            return ttsReady;
        }

        @JavascriptInterface
        public void speak(String text, String id) {
            if (!ttsReady || tts == null) {
                selesai(id);
                return;
            }
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), id);
        }

        @JavascriptInterface
        public void stop() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public String version() {
            return BuildConfig.VERSION_NAME;
        }

        @JavascriptInterface
        public boolean canUpdate() {
            return BuildConfig.SELF_UPDATE;
        }

        @JavascriptInterface
        public void checkUpdate() {
            if (BuildConfig.SELF_UPDATE) ui.post(() -> cekPembaruan(true));
        }

        @JavascriptInterface
        public void openTtsSettings() {
            ui.post(() -> {
                try {
                    Intent i = new Intent("com.android.settings.TTS_SETTINGS");
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    } catch (Exception ignored) {
                    }
                }
            });
        }
    }

    /* ================= PEMBARUAN ================= */

    private SharedPreferences pref() {
        return getSharedPreferences("pembaruan", MODE_PRIVATE);
    }

    /** true kalau versi a lebih baru dari b (format 1.2.3). */
    static boolean lebihBaru(String a, String b) {
        String[] x = a.split("\\."), y = b.split("\\.");
        for (int i = 0; i < Math.max(x.length, y.length); i++) {
            int p = i < x.length ? angka(x[i]) : 0, q = i < y.length ? angka(y[i]) : 0;
            if (p != q) return p > q;
        }
        return false;
    }

    private static int angka(String s) {
        try {
            return Integer.parseInt(s.replaceAll("[^0-9]", ""));
        } catch (Exception e) {
            return 0;
        }
    }

    private static String baca(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toString("UTF-8");
    }

    private void cekPembaruan(final boolean manual) {
        if (!BuildConfig.SELF_UPDATE || checking) return;
        checking = true;
        new Thread(() -> {
            String tag = null, apk = null, notes = "";
            boolean ok = false;
            try {
                URL u = new URL("https://api.github.com/repos/" + BuildConfig.UPDATE_REPO + "/releases/latest");
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setRequestProperty("User-Agent", "PanpanAkapan-Android");
                c.setConnectTimeout(8000);
                c.setReadTimeout(10000);
                if (c.getResponseCode() == 200) {
                    JSONObject o = new JSONObject(baca(c.getInputStream()));
                    tag = o.optString("tag_name", "").replaceFirst("^[vV]", "");
                    notes = o.optString("body", "");
                    JSONArray as = o.optJSONArray("assets");
                    if (as != null) for (int i = 0; i < as.length(); i++) {
                        JSONObject a = as.getJSONObject(i);
                        if (a.optString("name", "").toLowerCase(Locale.ROOT).endsWith(".apk")) {
                            apk = a.optString("browser_download_url", null);
                            break;
                        }
                    }
                    ok = true;
                }
                c.disconnect();
            } catch (Exception ignored) {
            }
            final boolean fOk = ok;
            final String fTag = tag, fApk = apk, fNotes = notes;
            ui.post(() -> {
                checking = false;
                if (isFinishing()) return;
                if (!fOk) {
                    if (manual) info("Belum bisa memeriksa", "Pastikan HP tersambung ke internet, lalu coba lagi.");
                    return;
                }
                boolean baru = fTag != null && fApk != null && lebihBaru(fTag, BuildConfig.VERSION_NAME);
                if (!baru) {
                    if (manual) info("Sudah versi terbaru", "Versi " + BuildConfig.VERSION_NAME + " sudah yang paling baru.");
                    return;
                }
                long tunda = pref().getLong("tunda_" + fTag, 0);
                if (!manual && System.currentTimeMillis() < tunda) return;
                tawarkan(fTag, fApk, fNotes);
            });
        }).start();
    }

    private void info(String judul, String isi) {
        new AlertDialog.Builder(this).setTitle(judul).setMessage(isi).setPositiveButton("Oke", null).show();
    }

    /**
     * Pembaruan sengaja TIDAK diunduh dan dipasang dari dalam aplikasi. Pola "unduh APK lalu pasang"
     * mirip perilaku dropper sehingga Play Protect bisa menandai aplikasi sebagai berbahaya.
     * Tautan APK dibuka di browser; Android sendiri yang mengurus unduhan dan pemasangan.
     */
    private void tawarkan(final String tag, final String url, String notes) {
        String n = notes == null ? "" : notes.trim();
        if (n.length() > 500) n = n.substring(0, 500) + "…";
        new AlertDialog.Builder(this)
                .setTitle("Versi " + tag + " sudah ada")
                .setMessage("Ada versi baru. Minta ayah atau ibu menekan Unduh, lalu buka berkas yang terunduh untuk memasangnya." + (n.isEmpty() ? "" : "\n\n" + n))
                .setCancelable(false)
                .setPositiveButton("Unduh", (d, w) -> bukaTautan(url))
                .setNegativeButton("Nanti", (d, w) -> pref().edit()
                        .putLong("tunda_" + tag, System.currentTimeMillis() + 24L * 3600 * 1000).apply())
                .show();
    }

    private void bukaTautan(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            info("Belum bisa membuka tautan", "Buka halaman rilis aplikasi di browser untuk mengunduh versi baru.");
        }
    }
}
